import { Link } from "react-router-dom";
import { ReactNode } from "react";

interface LayoutProps {
  children: ReactNode;
}

export function Layout({ children }: LayoutProps) {
  return (
    <div className="min-h-screen flex flex-col bg-background text-foreground">
      <header className="sticky top-0 z-40 border-b border-border/40 backdrop-blur-md bg-background/80">
        <div className="container flex h-16 max-w-7xl items-center justify-between">
          <Link
            to="/"
            className="flex items-center gap-2 font-bold text-xl tracking-tight hover:text-glow transition-colors"
          >
            <div className="relative w-8 h-8 flex items-center justify-center">
              <div className="absolute inset-0 bg-glow rounded-lg blur-md opacity-50 animate-glow-pulse" />
              <div className="relative bg-card rounded-lg px-1.5 py-0.5 text-xs font-black text-glow">
                H✦
              </div>
            </div>
            <span>HOLO✦PAD</span>
          </Link>

          <nav className="flex items-center gap-8">
            <Link
              to="/create"
              className="text-sm font-medium text-muted-foreground hover:text-foreground transition-colors"
            >
              Create
            </Link>
            <Link
              to="/"
              className="text-sm font-medium text-muted-foreground hover:text-foreground transition-colors"
            >
              Gallery
            </Link>
            <Link
              to="/create"
              className="px-4 py-2 rounded-lg bg-glow text-primary-foreground font-medium text-sm hover:shadow-glow-md transition-all hover:scale-105"
            >
              Start Creating
            </Link>
          </nav>
        </div>
      </header>

      <main className="flex-1">{children}</main>

      <footer className="border-t border-border/40 bg-card/50 mt-20">
        <div className="container max-w-7xl py-12 text-center text-sm text-muted-foreground">
          <p>© 2024 HOLO✦PAD. Transform your imagination into holograms.</p>
        </div>
      </footer>
    </div>
  );
}
