import { useLocation, useNavigate } from "react-router-dom";
import { ArrowLeft } from "lucide-react";
import { useEffect, useState, useRef } from "react";

export default function Viewer() {
  const location = useLocation();
  const navigate = useNavigate();
  const [mousePos, setMousePos] = useState({ x: 0, y: 0 });
  const [imageOffset, setImageOffset] = useState({ x: 0, y: 0 });
  const containerRef = useRef<HTMLDivElement>(null);

  const image = location.state?.image;

  // Redirect to upload if no image
  useEffect(() => {
    if (!image) {
      navigate("/upload");
    }
  }, [image, navigate]);

  // Handle mouse movement for parallax effect (desktop only)
  useEffect(() => {
    const handleMouseMove = (e: MouseEvent) => {
      if (!containerRef.current) return;

      const rect = containerRef.current.getBoundingClientRect();
      const centerX = rect.width / 2;
      const centerY = rect.height / 2;

      const x = (e.clientX - rect.left - centerX) / centerX;
      const y = (e.clientY - rect.top - centerY) / centerY;

      setMousePos({ x, y });
      setImageOffset({
        x: x * 8, // Subtle movement
        y: y * 8,
      });
    };

    // Only enable on devices that support hover
    if (!window.matchMedia("(hover: none)").matches) {
      window.addEventListener("mousemove", handleMouseMove);
      return () => window.removeEventListener("mousemove", handleMouseMove);
    }
  }, []);

  if (!image) return null;

  return (
    <div
      ref={containerRef}
      className="min-h-screen bg-black relative overflow-hidden flex items-center justify-center"
    >
      {/* Ambient light background */}
      <div className="absolute inset-0 overflow-hidden">
        <div className="absolute top-0 left-1/2 -translate-x-1/2 w-full h-96 bg-gradient-to-b from-glow/20 via-transparent to-transparent blur-3xl opacity-50" />
        <div className="absolute bottom-0 right-0 w-96 h-96 bg-glow-secondary/10 rounded-full blur-3xl opacity-40" />
      </div>

      {/* Main hologram container */}
      <div className="relative z-10 w-full h-full flex items-center justify-center">
        {/* Hologram wrapper with glow effects */}
        <div
          className="relative"
          style={{
            transform: `translate(${imageOffset.x}px, ${imageOffset.y}px)`,
            transition: "transform 0.1s ease-out",
          }}
        >
          {/* Outer glow layer */}
          <div className="absolute -inset-8 md:-inset-16 rounded-3xl bg-gradient-to-r from-glow via-glow-secondary to-glow opacity-0 blur-3xl animate-glow-pulse pointer-events-none" />

          {/* Inner glow layer */}
          <div className="absolute -inset-4 md:-inset-8 rounded-2xl bg-glow/20 blur-2xl animate-glow-pulse pointer-events-none" style={{ animationDelay: "0.5s" }} />

          {/* Image container with perspective */}
          <div className="relative rounded-2xl overflow-hidden backdrop-blur-sm border border-glow/30 shadow-2xl">
            {/* Gradient overlay for depth */}
            <div className="absolute inset-0 bg-gradient-to-br from-glow/20 via-transparent to-glow-secondary/20 pointer-events-none z-20" />

            {/* Floating animation container */}
            <div className="animate-float-up">
              <img
                src={image}
                alt="Hologram"
                className="w-full h-full object-cover max-w-2xl max-h-96 md:max-h-[70vh]"
                style={{
                  opacity: 0.95,
                  filter: "drop-shadow(0 0 30px rgba(0, 255, 255, 0.5))",
                }}
              />
            </div>

            {/* Light rays effect - horizontal */}
            <div className="absolute inset-0 pointer-events-none">
              <div className="absolute inset-0 bg-gradient-to-r from-transparent via-glow/10 to-transparent opacity-0 animate-shimmer" />
            </div>

            {/* Light rays effect - vertical */}
            <div className="absolute inset-0 pointer-events-none">
              <div className="absolute inset-0 bg-gradient-to-b from-transparent via-glow-secondary/10 to-transparent opacity-0 animate-shimmer" style={{ animationDelay: "1s" }} />
            </div>
          </div>

          {/* Soft light glow around image */}
          <div className="absolute inset-0 rounded-2xl bg-radial-glow pointer-events-none opacity-60 blur-2xl" style={{
            background: "radial-gradient(circle, rgba(0, 255, 255, 0.2) 0%, transparent 70%)",
          }} />
        </div>
      </div>

      {/* Minimal UI - top left */}
      <div className="absolute top-6 left-6 z-20">
        <button
          onClick={() => navigate("/upload")}
          className="flex items-center gap-2 px-4 py-2 rounded-lg border border-glow/40 text-glow hover:bg-glow/10 transition-all hover:border-glow/60"
        >
          <ArrowLeft className="w-4 h-4" />
          <span className="text-sm font-medium hidden sm:inline">Upload New</span>
        </button>
      </div>

      {/* Status text - center bottom (optional) */}
      <div className="absolute bottom-6 left-1/2 -translate-x-1/2 z-20 text-center">
        <p className="text-glow/60 text-sm font-light">HoloStage Active</p>
      </div>

      {/* Subtle grid lines for context */}
      <div className="absolute inset-0 pointer-events-none opacity-5">
        <div
          className="w-full h-full"
          style={{
            backgroundImage: `
              linear-gradient(0deg, transparent 24%, rgba(0, 255, 255, .05) 25%, rgba(0, 255, 255, .05) 26%, transparent 27%, transparent 74%, rgba(0, 255, 255, .05) 75%, rgba(0, 255, 255, .05) 76%, transparent 77%, transparent),
              linear-gradient(90deg, transparent 24%, rgba(0, 255, 255, .05) 25%, rgba(0, 255, 255, .05) 26%, transparent 27%, transparent 74%, rgba(0, 255, 255, .05) 75%, rgba(0, 255, 255, .05) 76%, transparent 77%, transparent)
            `,
            backgroundSize: "50px 50px",
          }}
        />
      </div>
    </div>
  );
}
