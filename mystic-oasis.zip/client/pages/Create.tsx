import { Link, useNavigate } from "react-router-dom";
import { Upload } from "lucide-react";
import { useState } from "react";

export default function UploadScreen() {
  const [uploadedImage, setUploadedImage] = useState<string | null>(null);
  const navigate = useNavigate();

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (event) => {
        const imageData = event.target?.result as string;
        setUploadedImage(imageData);
        // Auto-navigate to viewer after upload
        setTimeout(() => {
          navigate("/viewer", { state: { image: imageData } });
        }, 500);
      };
      reader.readAsDataURL(file);
    }
  };

  return (
    <div className="min-h-screen bg-black flex flex-col items-center justify-center relative overflow-hidden px-4">
      {/* Subtle background glow */}
      <div className="absolute inset-0 overflow-hidden">
        <div className="absolute top-1/4 left-1/2 -translate-x-1/2 w-96 h-96 bg-glow/10 rounded-full blur-3xl" />
      </div>

      <div className="relative z-10 flex flex-col items-center justify-center max-w-2xl w-full">
        {/* Logo (smaller) */}
        <Link to="/" className="mb-12 inline-block">
          <div className="relative group">
            <div className="absolute inset-0 bg-glow rounded-lg blur-md opacity-40 group-hover:opacity-60 transition-opacity" />
            <div className="relative bg-card/80 backdrop-blur-md rounded-lg px-3 py-2 border border-glow/40">
              <span className="text-2xl font-black text-glow">H✦</span>
            </div>
          </div>
        </Link>

        {/* Main content */}
        <div className="text-center mb-12">
          <h1 className="text-4xl md:text-5xl font-black text-white mb-3">
            Choose an image
          </h1>
          <p className="text-lg text-muted-foreground">
            We'll transform it into light.
          </p>
        </div>

        {/* Upload area */}
        <div className="w-full">
          <label className="relative block w-full aspect-square rounded-2xl border-2 border-dashed border-glow/40 bg-gradient-to-br from-glow/5 to-glow-secondary/5 hover:border-glow/60 transition-colors cursor-pointer group overflow-hidden">
            {/* Background glow on hover */}
            <div className="absolute inset-0 bg-gradient-to-br from-glow/10 via-transparent to-glow-secondary/10 opacity-0 group-hover:opacity-100 transition-opacity" />

            {/* Content */}
            <div className="relative w-full h-full flex flex-col items-center justify-center">
              {uploadedImage ? (
                <div className="w-full h-full relative">
                  <img
                    src={uploadedImage}
                    alt="Uploaded"
                    className="w-full h-full object-cover"
                  />
                  <div className="absolute inset-0 bg-black/30 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                    <span className="text-white font-medium flex items-center gap-2">
                      <Upload className="w-4 h-4" />
                      Change
                    </span>
                  </div>
                </div>
              ) : (
                <div className="text-center">
                  <div className="mb-4 inline-block p-4 rounded-lg bg-glow/10 border border-glow/20">
                    <Upload className="w-8 h-8 text-glow" />
                  </div>
                  <p className="text-foreground font-medium">Click to upload</p>
                  <p className="text-sm text-muted-foreground mt-2">
                    JPG, PNG, or WebP
                  </p>
                </div>
              )}
            </div>

            <input
              type="file"
              accept="image/*"
              onChange={handleImageUpload}
              className="hidden"
            />
          </label>
        </div>

        {/* Back button */}
        <div className="mt-8">
          <Link
            to="/"
            className="text-muted-foreground hover:text-foreground transition-colors text-sm"
          >
            ← Back
          </Link>
        </div>
      </div>
    </div>
  );
}
