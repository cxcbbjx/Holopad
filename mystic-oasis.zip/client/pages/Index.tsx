import { Link } from "react-router-dom";

export default function Landing() {
  return (
    <div className="min-h-screen bg-black flex items-center justify-center relative overflow-hidden">
      {/* Animated glow orbs behind logo */}
      <div className="absolute inset-0 overflow-hidden">
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-96 h-96 bg-glow/30 rounded-full blur-3xl animate-glow-pulse" />
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-80 h-80 bg-glow-secondary/20 rounded-full blur-3xl animate-glow-pulse" style={{ animationDelay: "1s" }} />
      </div>

      {/* Content */}
      <div className="relative z-10 flex flex-col items-center justify-center text-center px-4">
        {/* Logo with glow */}
        <div className="mb-12 animate-float-up">
          <div className="relative">
            {/* Glow effect behind logo */}
            <div className="absolute inset-0 bg-glow rounded-2xl blur-2xl opacity-60 animate-glow-pulse" />
            
            {/* Logo box */}
            <div className="relative bg-card/80 backdrop-blur-md rounded-2xl p-6 border border-glow/40">
              <div className="text-6xl font-black tracking-tighter">
                <span className="text-transparent bg-clip-text bg-gradient-to-r from-glow via-glow-secondary to-glow">
                  ✦
                </span>
              </div>
            </div>
          </div>
        </div>

        {/* Brand text */}
        <h1 className="text-5xl md:text-6xl font-black mb-4 text-white animate-float-up tracking-tight" style={{ animationDelay: "0.1s" }}>
          HOLO✦PAD
        </h1>

        <p className="text-xl md:text-2xl text-glow/80 mb-12 font-light animate-float-up" style={{ animationDelay: "0.2s" }}>
          Turn images into light.
        </p>

        {/* Get Started button */}
        <Link
          to="/upload"
          className="px-8 py-4 rounded-lg bg-gradient-to-r from-glow to-glow-secondary text-black font-bold text-lg hover:shadow-glow-lg transition-all hover:scale-105 animate-float-up"
          style={{ animationDelay: "0.3s" }}
        >
          Get Started
        </Link>
      </div>
    </div>
  );
}
